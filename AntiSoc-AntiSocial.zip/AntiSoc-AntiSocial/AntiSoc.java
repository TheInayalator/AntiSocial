public class AntiSoc {
    public static void main (String args[]) {
        System.out.println("Now we finally get to treatment!");
        System.out.println("Some people suggest that you interact with others off the app.");
        System.out.println("So, Use the exercises we have learned in a conversation.");
        System.out.println("Try not to rush the conversations, otherwise the other person feels scattered.");
    }
}