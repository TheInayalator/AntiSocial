public class Antisoc {
    public static void main (String [] args) {
        System.out.print("Now that you evaluated yourself...");
        System.out.println("Let's see how I can help you!");
        System.out.println("Antisocial behaviour originates from childhood.");
        System.out.println("Sometimes, behaviour begins from a parent's poor acknowledgement.");
        System.out.print("Think about where your behaviour originates (hint: it could be in a unfamiliar environment)");
    }
}