public class MyClass {
    public static void main(String args[]) {
     System.out.println("Another treatment option is joining social media.");
     System.out.println("However, for some, it can be very scary...");
     System.out.println("The only way to succeed in life is to keep some things spontaneous, while keeping some things under control.");
     System.out.println("You have to take the risk, but know when to stay safe.");
     System.out.println("In social media, you can reconnect with distant relatives.");
     System.out.println("However, there is a risk, in exchanging data, promoting products, etc.");
     System.out.println("The only way to stay safe on socil media is not to post anything too personal, and not something too vague!");
     System.out.println("Write how many risks you have taken today.");
import java.util.Scanner;
    class main {
        public static void main (String args[]) {
        Scanner myObj= new Scanner (System.in);
        int risks = 4;
        for (risks= 1; risks < 4) {
         if (risks== 1) {
             continue;
         }
         System.out.println("You need to take a little more risks.");
     }
            }
        }
    }
}