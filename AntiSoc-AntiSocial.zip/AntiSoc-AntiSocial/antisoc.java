public class antisoc {
    public static void main (String [] args) {
      System.out.println("How are you today?");
      System.out.println("This is a question we ask each other everyday.");
      System.out.print("Today, we ask ourselves.");
    }
}